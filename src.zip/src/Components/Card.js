import React from 'react';

function Card({ data }) {
  return (
    <div className="card">
      <h2>{data.id}</h2>
      <h3>{data.name}</h3>
      <p>{data.description}</p>
      <p>{data.createdTime}</p>
      <p>{data.color}</p>
    </div>
  );
}

export default Card;
