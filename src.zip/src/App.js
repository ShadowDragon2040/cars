import DataList from "./Components/Datalist";

function App() {
  return (
    <div className="App">
      <DataList/>
    </div>
  );
}

export default App;